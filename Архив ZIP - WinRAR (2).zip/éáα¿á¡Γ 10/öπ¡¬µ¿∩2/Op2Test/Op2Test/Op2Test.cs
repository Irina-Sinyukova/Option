﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Option10_2_;

namespace Op2Test
{
    [TestClass]
    public class Op2Test
    {
        Op20 d = new Op20();
        [TestMethod]
        public void TestMethod1()
        {
            double a = 3.2; double b = 17.5; double x = -4.8;

            double expected = 0.438148;
            double actual = d.Fun(a, b, x);
            Assert.AreEqual(expected, actual);
        }
        public void TestMethod2()
        {
            double a = 5; double b = 1; double x = 10;

            double expected = -4.85039;
            double actual = d.Fun(a, b, x);
            Assert.AreEqual(expected, actual);
        }
        public void TestMethod3()
        {
            double a = 5; double b = 100; double x = 1;

            double expected = 130.57332;
            double actual = d.Fun(a, b, x);
            Assert.AreEqual(expected, actual);
        }
        public void TestMethod4()
        {
            double a = 7; double b = 0; double x = 14;

            double expected = -7.69825;
            double actual = d.Fun(a, b, x);
            Assert.AreEqual(expected, actual);
        }
        public void TestMethod5()
        {
            double a = 1; double b = 1; double x = 1;

            double expected = 0.369013;
            double actual = d.Fun(a, b, x);
            Assert.AreEqual(expected, actual);
        }
    }
}
