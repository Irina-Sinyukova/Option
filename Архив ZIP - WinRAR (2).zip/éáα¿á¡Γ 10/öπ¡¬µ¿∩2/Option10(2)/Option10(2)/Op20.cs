﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Option10_2_
{
    public class Op20
    {
        public double Fun(double a, double b, double x)
        {
            double D = Math.Cos(b * x / a);
            return D;
        }
    }
}
